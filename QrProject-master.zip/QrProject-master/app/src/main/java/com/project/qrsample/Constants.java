package com.project.qrsample;

/**
 * Created by Cyber on 4/17/2016.
 */
public class Constants {

    public  static  String ip="http://192.168.31.79:8888/threelevel/user/resultFromApp.php";

    public static String ApiLink="http://192.168.31.79:8888/threelevel/user/loginapi.php";
}
